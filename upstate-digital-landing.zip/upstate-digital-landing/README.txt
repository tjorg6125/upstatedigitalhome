UPSTATE DIGITAL — LANDING PAGE

Files:
- index.html
- styles.css
- script.js
- assets/upstate-digital-logo.png

Before publishing:
1. Open index.html and replace `your-email@example.com` in the form action with the email address that should receive inquiries.
   Example: https://formsubmit.co/hello@upstatedigitalsc.com
2. Upload the folder contents to Cloudflare Pages or another static host.
3. In Cloudflare Pages, set `index.html` as the entry page automatically by publishing the folder.

This site is plain HTML/CSS/JS — no build step or framework needed.
